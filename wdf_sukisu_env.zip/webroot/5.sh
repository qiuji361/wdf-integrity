#!/system/bin/sh

# Author: 王德发刷机

_wdf_self="${0%/*}"
[ "$_wdf_self" = "$0" ] && _wdf_self="$(pwd)"
_wdf_moddir="${_wdf_self%/*}"
[ -d "$_wdf_moddir/webroot" ] || _wdf_moddir="/data/adb/modules/wdf_sukisu_env"
_wdf_loader="$_wdf_moddir/wdf_loader"
if [ ! -x "$_wdf_loader" ] || ! "$_wdf_loader" "$_wdf_moddir" >/dev/null 2>&1; then
    echo "完整性校验失败，已阻止执行。盗版王德发环境请联系王德发刷机" >&2
    exit 9
fi
unset _wdf_self _wdf_moddir _wdf_loader

SCRIPT_DIR="${0%/*}"
[ "$SCRIPT_DIR" = "$0" ] && SCRIPT_DIR="$(pwd)"

CPU_URL="https://github.com/qiuji361/wdf-device-guise/releases/download/v1.0.0/cpuwz_v1.4.zip"
CPU_SHA256="3d3f732b1ccb16e42c13449db679554c0ce06147da8457a2549efcd317618068"
WORK_DIR="/data/local/tmp/wdf_remote_modules"
CPU_ZIP="$WORK_DIR/cpuwz_v1.4.zip"
MODULE_ID="cpuwz"
MODULE_DIR="/data/adb/modules/$MODULE_ID"
DISABLE_FILE="$MODULE_DIR/disable"

usage() {
    echo "用法: sh 5.sh [--install|--status|--disable|--enable]"
    echo "  --install  安装或更新 CPU 伪装模块"
    echo "  --status   查看模块状态"
    echo "  --disable  停用 CPU 伪装模块"
    echo "  --enable   启用 CPU 伪装模块"
}

register_manager() {
    MANAGER_COUNT=$((MANAGER_COUNT + 1))
    MANAGER_TYPE="$1"
    MANAGER_PATH="$2"
}

detect_manager() {
    MANAGER_COUNT=0
    MANAGER_TYPE=""
    MANAGER_PATH=""

    if [ -x "/data/adb/ksud" ]; then
        register_manager "KernelSU" "/data/adb/ksud"
    fi

    magisk_path="$(command -v magisk 2>/dev/null)"
    if [ -n "$magisk_path" ] && [ -x "$magisk_path" ]; then
        register_manager "Magisk" "$magisk_path"
    fi

    if [ -x "/data/adb/ap/bin/apd" ]; then
        register_manager "APatch" "/data/adb/ap/bin/apd"
    fi
}

install_zip() {
    case "$MANAGER_TYPE" in
        KernelSU|APatch)
            "$MANAGER_PATH" module install "$CPU_ZIP"
            ;;
        Magisk)
            "$MANAGER_PATH" --install-module "$CPU_ZIP"
            ;;
        *)
            return 1
            ;;
    esac
}

download_cpu_zip() {
    mkdir -p "$WORK_DIR" || return 1
    tmp="$CPU_ZIP.tmp"
    rm -f "$tmp"

    echo "[1/4] 下载 CPU 伪装模块"
    download_ok=0
    if command -v curl >/dev/null 2>&1; then
        curl -LfsS --connect-timeout 20 --retry 2 -o "$tmp" "$CPU_URL" && download_ok=1
    fi
    if [ "$download_ok" != 1 ] && command -v wget >/dev/null 2>&1; then
        wget -q -O "$tmp" "$CPU_URL" && download_ok=1
    fi
    if [ "$download_ok" != 1 ] && command -v busybox >/dev/null 2>&1; then
        busybox wget -q -O "$tmp" "$CPU_URL" && download_ok=1
    fi
    if [ "$download_ok" != 1 ]; then
        echo "错误: 下载失败，请确认网络或加速器可用"
        return 1
    fi
    [ -s "$tmp" ] || {
        echo "错误: 下载失败，文件为空"
        return 1
    }

    echo "[2/4] 校验 SHA256"
    actual="$(sha256sum "$tmp" 2>/dev/null | awk '{print tolower($1)}')"
    if [ -z "$actual" ] && command -v toybox >/dev/null 2>&1; then
        actual="$(toybox sha256sum "$tmp" 2>/dev/null | awk '{print tolower($1)}')"
    fi
    if [ -z "$actual" ] && command -v busybox >/dev/null 2>&1; then
        actual="$(busybox sha256sum "$tmp" 2>/dev/null | awk '{print tolower($1)}')"
    fi
    if [ -z "$actual" ]; then
        echo "错误: 系统缺少 sha256sum"
        return 1
    fi
    if [ "$actual" != "$CPU_SHA256" ]; then
        echo "错误: SHA256 不匹配 $actual"
        return 1
    fi

    mv "$tmp" "$CPU_ZIP" || return 1
    chmod 0644 "$CPU_ZIP"
}

show_status() {
    if [ -d "$MODULE_DIR" ]; then
        echo "CPU 伪装模块已安装: $MODULE_DIR"
        if [ -f "$DISABLE_FILE" ]; then
            echo "当前状态: 已停用"
        else
            echo "当前状态: 已启用或等待重启生效"
        fi
    else
        echo "CPU 伪装模块未安装"
    fi
}

install_cpu_module() {
    echo "=== CPU 伪装模块安装 ==="
    download_cpu_zip || return 1

    detect_manager
    if [ "$MANAGER_COUNT" -eq 0 ]; then
        echo "错误: 未找到可用的 KernelSU/Magisk/APatch 命令行工具"
        return 1
    fi

    if [ "$MANAGER_COUNT" -ne 1 ]; then
        echo "错误: 检测到多个 Root 管理器命令行工具，请保留一个后再试"
        return 1
    fi

    echo "[3/4] 使用 $MANAGER_TYPE 安装: $MANAGER_PATH"
    if install_zip; then
        echo "[4/4] CPU 伪装模块安装命令执行完成，重启后生效"
        echo "注意: 需要配合 Zygisk Next，并开启仅还原挂载功能"
        return 0
    fi

    echo "错误: CPU 伪装模块安装失败"
    return 1
}

disable_module() {
    if [ ! -d "$MODULE_DIR" ]; then
        echo "CPU 伪装模块未安装"
        return 1
    fi

    touch "$DISABLE_FILE" || {
        echo "错误: 无法写入停用标记"
        return 1
    }
    echo "CPU 伪装模块已设置为停用，重启后生效"
}

enable_module() {
    if [ ! -d "$MODULE_DIR" ]; then
        echo "CPU 伪装模块未安装"
        return 1
    fi

    rm -f "$DISABLE_FILE" || {
        echo "错误: 无法移除停用标记"
        return 1
    }
    echo "CPU 伪装模块已设置为启用，重启后生效"
}

case "$1" in
    ""|--install|install)
        install_cpu_module
        ;;
    --status|status)
        show_status
        ;;
    --disable|disable)
        disable_module
        ;;
    --enable|enable)
        enable_module
        ;;
    *)
        usage
        exit 1
        ;;
esac
