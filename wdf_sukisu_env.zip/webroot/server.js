const fs = require("fs");
const http = require("http");
const path = require("path");

const root = path.resolve(process.argv[2] || ".");
const port = Number(process.argv[3]) || 8080;
const mime = {
  ".html": "text/html; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".sh": "text/plain; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
};

http.createServer((req, res) => {
  try {
    const url = new URL(req.url, "http://127.0.0.1");
    let rel = decodeURIComponent(url.pathname.replace(/^\/+/, "")) || "index.html";
    if (rel.includes("..")) {
      res.writeHead(403);
      res.end("forbidden");
      return;
    }

    const file = path.resolve(root, rel);
    if (!file.startsWith(root) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
      res.writeHead(404);
      res.end("not found");
      return;
    }

    res.writeHead(200, {
      "content-type": mime[path.extname(file)] || "application/octet-stream",
      "cache-control": "no-store",
    });
    fs.createReadStream(file).pipe(res);
  } catch (error) {
    res.writeHead(500);
    res.end(String(error && error.stack || error));
  }
}).listen(port, "127.0.0.1", () => {
  console.log(`Server running at http://localhost:${port}/`);
  console.log(`Serving files from: ${root}`);
});
