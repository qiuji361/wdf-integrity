#!/system/bin/sh

# Author: 王德发刷机

_wdf_self="${0%/*}"
[ "$_wdf_self" = "$0" ] && _wdf_self="$(pwd)"
_wdf_moddir="${_wdf_self%/*}"
[ -d "$_wdf_moddir/webroot" ] || _wdf_moddir="/data/adb/modules/wdf_sukisu_env"
_wdf_loader="$_wdf_moddir/wdf_loader"
if [ ! -x "$_wdf_loader" ] || ! "$_wdf_loader" "$_wdf_moddir" >/dev/null 2>&1; then
    echo "完整性校验失败，已阻止执行。盗版王德发环境请联系王德发刷机" >&2
    exit 9
fi

_wdf_susfs="$_wdf_moddir/wdf_susfs"
if [ ! -x "$_wdf_susfs" ]; then
    echo "wdf_susfs 缺失或不可执行" >&2
    exit 8
fi
unset _wdf_self _wdf_loader

exec "$_wdf_susfs" --moddir "$_wdf_moddir" "$@"
