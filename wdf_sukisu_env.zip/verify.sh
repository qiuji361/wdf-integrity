#!/system/bin/sh

MODDIR="${0%/*}"
[ "$MODDIR" = "$0" ] && MODDIR="/data/adb/modules/wdf_sukisu_env"

LOADER="$MODDIR/wdf_loader"
WARN_FILE="$MODDIR/.wdf_integrity_warn"

write_warn() {
  {
    echo "status=tampered"
    echo "code=$1"
    echo "checked_at=$(date +%s 2>/dev/null || echo unknown)"
    echo "files=$2"
    echo "message=$3"
  } > "$WARN_FILE" 2>/dev/null
}

if [ ! -f "$LOADER" ]; then
  write_warn 10 "wdf_loader" "integrity loader missing"
  touch "$MODDIR/disable" 2>/dev/null || true
  echo "integrity loader missing: $LOADER" >&2
  exit 10
fi

"$LOADER" "$MODDIR"
rc=$?
if [ "$rc" -ne 0 ]; then
  touch "$MODDIR/disable" 2>/dev/null || true
fi
exit "$rc"
