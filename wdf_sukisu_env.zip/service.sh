#!/system/bin/sh

MODDIR="${0%/*}"
[ "$MODDIR" = "$0" ] && MODDIR="/data/adb/modules/wdf_sukisu_env"

SCRIPT_1="$MODDIR/webroot/1.sh"
[ -f "$SCRIPT_1" ] || SCRIPT_1="/data/adb/modules/wdf_sukisu_env/webroot/1.sh"

IMPORT_MARK="$MODDIR/.wdf_hma_imported"
LOADER_BIN="$MODDIR/wdf_loader"
WARN_FILE="$MODDIR/.wdf_integrity_warn"
REMOTE_CONFIG_FILE="$MODDIR/remote_integrity.conf"
REMOTE_LOG_FILE="$MODDIR/.wdf_integrity_remote"

write_warn() {
    {
        echo "status=tampered"
        echo "code=$1"
        echo "checked_at=$(date +%s 2>/dev/null || echo unknown)"
        echo "files=$2"
        echo "message=$3"
    } > "$WARN_FILE" 2>/dev/null
}

disable_module() {
    touch "$MODDIR/disable" 2>/dev/null || true
}

log_remote() {
    {
        echo "checked_at=$(date +%s 2>/dev/null || echo unknown)"
        echo "$1"
    } > "$REMOTE_LOG_FILE" 2>/dev/null || true
}

verify_or_disable() {
    if [ ! -f "$LOADER_BIN" ]; then
        write_warn 10 "wdf_loader" "integrity loader missing"
        disable_module
        return 1
    fi
    if ! "$LOADER_BIN" "$MODDIR" >/dev/null 2>&1; then
        disable_module
        return 1
    fi
    return 0
}

remote_defaults() {
    REMOTE_INTEGRITY_ENABLED=1
    REMOTE_FAIL_SECURE=0
    REMOTE_HASH_URL=""
    REMOTE_HASH_BASE_URL=""
    REMOTE_HASH_VERSION_MODE="versioned"
    REMOTE_HASH_FILE="hashes.txt"
    REMOTE_CONNECT_TIMEOUT=5
    REMOTE_MAX_TIME=12
    REMOTE_FETCH_MAX_BYTES=16384
    REMOTE_MIN_HIT=17
    REMOTE_CHECKED_FILES="
      wdf_verify
      wdf_loader
      wdf_mark
      wdf_spoof
      wdf_susfs
      service.sh
      verify.sh
      module.prop
      remote_integrity.conf
      webroot/index.html
      webroot/device-guise.html
      webroot/devices.json
      webroot/2.sh
      webroot/3.sh
      webroot/4.sh
      webroot/5.sh
      webroot/server.js
    "
}

load_remote_config() {
    remote_defaults
    [ -f "$REMOTE_CONFIG_FILE" ] || {
        log_remote "remote=skipped reason=config_missing"
        return 0
    }
    if ! /system/bin/sh -n "$REMOTE_CONFIG_FILE" >/dev/null 2>&1; then
        REMOTE_INTEGRITY_ENABLED=0
        log_remote "remote=skipped reason=config_syntax"
        return 0
    fi
    . "$REMOTE_CONFIG_FILE" >/dev/null 2>&1 || {
        REMOTE_INTEGRITY_ENABLED=0
        log_remote "remote=skipped reason=config_source_failed"
        return 0
    }
}

sanitize_remote_config() {
    case "$REMOTE_CONNECT_TIMEOUT" in ""|*[!0-9]*) REMOTE_CONNECT_TIMEOUT=5 ;; esac
    case "$REMOTE_MAX_TIME" in ""|*[!0-9]*) REMOTE_MAX_TIME=12 ;; esac
    case "$REMOTE_FETCH_MAX_BYTES" in ""|*[!0-9]*) REMOTE_FETCH_MAX_BYTES=16384 ;; esac
    case "$REMOTE_MIN_HIT" in ""|*[!0-9]*) REMOTE_MIN_HIT=15 ;; esac
    [ "$REMOTE_CONNECT_TIMEOUT" -gt 0 ] 2>/dev/null || REMOTE_CONNECT_TIMEOUT=5
    [ "$REMOTE_MAX_TIME" -gt 0 ] 2>/dev/null || REMOTE_MAX_TIME=12
    [ "$REMOTE_FETCH_MAX_BYTES" -gt 0 ] 2>/dev/null || REMOTE_FETCH_MAX_BYTES=16384
    [ "$REMOTE_MIN_HIT" -gt 0 ] 2>/dev/null || REMOTE_MIN_HIT=15
    [ -n "$REMOTE_HASH_FILE" ] || REMOTE_HASH_FILE="hashes.txt"
    case "$REMOTE_HASH_VERSION_MODE" in
        latest|flat|versioned) ;;
        *) REMOTE_HASH_VERSION_MODE="versioned" ;;
    esac
}

remote_fail_secure() {
    _secure="$(printf '%s' "$REMOTE_FAIL_SECURE" | tr 'A-Z' 'a-z')"
    case "$_secure" in
        1|true|yes|on|strict|enabled) return 0 ;;
    esac
    return 1
}

remote_soft_fail() {
    if remote_fail_secure; then
        write_warn 19 "remote" "$1"
        disable_module
        log_remote "remote=tampered reason=$2 mode=strict"
        return 1
    fi
    log_remote "remote=skipped reason=$2"
    return 0
}

remote_enabled() {
    _enabled="$(printf '%s' "$REMOTE_INTEGRITY_ENABLED" | tr 'A-Z' 'a-z')"
    case "$_enabled" in
        0|false|no|off|disabled) return 1 ;;
    esac
    return 0
}

build_remote_hash_url() {
    if [ -n "$REMOTE_HASH_URL" ]; then
        printf '%s\n' "$REMOTE_HASH_URL"
        return 0
    fi
    _base="${REMOTE_HASH_BASE_URL%/}"
    [ -n "$_base" ] || return 1
    case "$REMOTE_HASH_VERSION_MODE" in
        latest|flat)
            printf '%s/%s\n' "$_base" "$REMOTE_HASH_FILE"
            ;;
        *)
            printf '%s/v%s/%s\n' "$_base" "$MODULE_VERSION" "$REMOTE_HASH_FILE"
            ;;
    esac
}

is_sha256_hex() {
    printf '%s\n' "$1" | grep -Eq '^[0-9a-f]{64}$'
}

sha256_of_file() {
    target="$1"
    [ -f "$target" ] || { echo ""; return 2; }
    out="$(sha256sum "$target" 2>/dev/null | sed 's/[[:space:]].*$//' | tr 'A-F' 'a-f')"
    [ -n "$out" ] || out="$(toybox sha256sum "$target" 2>/dev/null | sed 's/[[:space:]].*$//' | tr 'A-F' 'a-f')"
    [ -n "$out" ] || out="$(busybox sha256sum "$target" 2>/dev/null | sed 's/[[:space:]].*$//' | tr 'A-F' 'a-f')"
    if is_sha256_hex "$out"; then
        echo "$out"
        return 0
    fi
    echo ""
    return 1
}

make_remote_tmp() {
    _base="${TMPDIR:-/data/local/tmp}"
    if command -v mktemp >/dev/null 2>&1; then
        _tmp="$(mktemp "$_base/wdf_hashes.XXXXXX" 2>/dev/null)" && { echo "$_tmp"; return 0; }
        _tmp="$(mktemp 2>/dev/null)" && { echo "$_tmp"; return 0; }
    fi
    echo "$_base/wdf_hashes.$$.$(date +%s 2>/dev/null)"
}

fetch_remote_hashes() {
    _url="$1"
    if command -v curl >/dev/null 2>&1; then
        _tmp="$(make_remote_tmp)"
        [ -n "$_tmp" ] || return 1
        _code="$(curl -LfsS -o "$_tmp" -w '%{http_code}' \
            --connect-timeout "$REMOTE_CONNECT_TIMEOUT" --max-time "$REMOTE_MAX_TIME" "$_url" 2>/dev/null)"
        _rc=$?
        if [ "$_rc" -ne 0 ]; then
            rm -f "$_tmp"
            return 1
        fi
        case "$_code" in
            200) cat "$_tmp"; rm -f "$_tmp"; return 0 ;;
            *) rm -f "$_tmp"; return 1 ;;
        esac
    fi
    if command -v wget >/dev/null 2>&1; then
        wget -T "$REMOTE_MAX_TIME" -q -O - "$_url" 2>/dev/null
        return $?
    fi
    if command -v busybox >/dev/null 2>&1; then
        busybox wget -T "$REMOTE_MAX_TIME" -q -O - "$_url" 2>/dev/null
        return $?
    fi
    return 1
}

extract_hash() {
    _content="$1"
    _file="$2"
    printf '%s\n' "$_content" | while IFS= read -r _line; do
        _key="${_line%%=*}"
        [ "$_key" = "$_file" ] || continue
        _value="${_line#*=}"
        printf '%s\n' "$_value" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | tr 'A-F' 'a-f'
        return 0
    done
}

remote_verify_or_disable() {
    load_remote_config
    sanitize_remote_config
    if ! remote_enabled; then
        log_remote "remote=skipped reason=disabled"
        return 0
    fi

    _url="$(build_remote_hash_url)" || {
        log_remote "remote=skipped reason=not_configured"
        return 0
    }

    raw_hashes="$(fetch_remote_hashes "$_url" | tr -d '\r' | head -c "$REMOTE_FETCH_MAX_BYTES")"
    [ -n "$raw_hashes" ] || {
        remote_soft_fail "remote hashes fetch failed" "fetch_failed"
        return $?
    }

    hashes="$(printf '%s\n' "$raw_hashes" | grep '=')"

    remote_version="$(extract_hash "$hashes" "version")"
    if [ -n "$remote_version" ] && [ -n "$MODULE_VERSION" ] && \
       [ "$remote_version" != "$MODULE_VERSION" ]; then
        remote_soft_fail "remote hashes version mismatch remote=$remote_version local=$MODULE_VERSION" "version_mismatch"
        return $?
    fi

    valid=0
    bad=""
    sha256_unavailable=0

    for file in $REMOTE_CHECKED_FILES; do
        [ -n "$file" ] || continue
        expected="$(extract_hash "$hashes" "$file")"
        is_sha256_hex "$expected" || continue
        valid=$((valid + 1))

        actual="$(sha256_of_file "$MODDIR/$file")"
        _rc=$?
        if [ "$_rc" -eq 2 ]; then
            bad="${bad}${bad:+,}${file}"
            continue
        fi
        if [ "$_rc" -ne 0 ]; then
            sha256_unavailable=1
            log_remote "remote=skipped reason=sha256_unavailable file=$file"
            continue
        fi
        if [ "$actual" != "$expected" ]; then
            bad="${bad}${bad:+,}${file}"
        fi
    done

    [ "$valid" -ge 1 ] || {
        remote_soft_fail "no valid remote entries" "no_valid_entries"
        return $?
    }

    if [ -n "$bad" ]; then
        write_warn 18 "$bad" "remote integrity check failed"
        disable_module
        log_remote "remote=tampered files=$bad"
        return 1
    fi

    [ "$sha256_unavailable" = "0" ] || {
        remote_soft_fail "sha256 tool unavailable for some files" "sha256_partial_fail"
        return $?
    }

    if [ "$valid" -lt "$REMOTE_MIN_HIT" ]; then
        remote_soft_fail "too few valid remote entries valid=$valid min=$REMOTE_MIN_HIT" "too_few_entries"
        return $?
    fi

    log_remote "remote=verified files=$valid"
    return 0
}

verify_or_disable || exit 0

while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
  sleep 2
done

sleep 5

while dumpsys window 2>/dev/null | grep -q "mInputRestricted=true"; do
  sleep 3
done

verify_or_disable || exit 0

MODULE_VERSION="$(grep '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
[ -n "$MODULE_VERSION" ] || MODULE_VERSION="0.1"

remote_verify_or_disable || exit 0

MARK_BIN="$MODDIR/wdf_mark"
[ -x "$MARK_BIN" ] && "$MARK_BIN" --apphide-boot-restore >/dev/null 2>&1

SPOOF_BIN="$MODDIR/wdf_spoof"
[ -x "$SPOOF_BIN" ] && "$SPOOF_BIN" --moddir "$MODDIR" id-boot-apply >/dev/null 2>&1

HMA_DIR="/data/user/0/org.frknkrc44.hma_oss/files"
if [ -d "/proc/1/root$HMA_DIR" ]; then
    HMA_DIR="/proc/1/root$HMA_DIR"
fi

CONFIG_FILE="$HMA_DIR/config.json"

[ -d "$HMA_DIR" ] || exit 0
[ -f "$SCRIPT_1" ] || exit 0

if [ -f "$IMPORT_MARK" ] && [ -f "$CONFIG_FILE" ]; then
    CACHED_VERSION="$(cat "$IMPORT_MARK" 2>/dev/null)"
    if [ "$CACHED_VERSION" = "$MODULE_VERSION" ]; then
        exit 0
    fi
fi

verify_or_disable || exit 0

if /system/bin/sh "$SCRIPT_1" >/dev/null 2>&1; then
    echo "$MODULE_VERSION" > "$IMPORT_MARK"
fi

exit 0
