#!/system/bin/sh

abort_install() {
  if command -v abort >/dev/null 2>&1; then
    abort "$1"
  else
    echo "$1"
  fi
  exit 2
}

restore_selinux() {
  if [ "$SELINUX_CHANGED" = "1" ]; then
    echo "还原 selinux 模式为强制模式"
    setenforce 1 2>/dev/null || echo "警告: selinux 模式还原失败，请手动检查"
    SELINUX_CHANGED=0
  fi
}

register_manager() {
  ManagerNumber=$((ManagerNumber + 1))
  ManagerType="$1"
  manager_path="$2"
  echo "发现 $ManagerType 命令行文件可用: $manager_path"
}

detect_manager() {
  ManagerNumber=0
  ManagerType=""
  manager_path=""

  if [ -x "/data/adb/ksud" ]; then
    register_manager "KernelSU" "/data/adb/ksud"
  fi

  magisk_path="$(command -v magisk 2>/dev/null)"
  if [ -n "$magisk_path" ] && [ -x "$magisk_path" ]; then
    register_manager "Magisk" "$magisk_path"
  fi

  if [ -x "/data/adb/ap/bin/apd" ]; then
    register_manager "APatch" "/data/adb/ap/bin/apd"
  fi
}

install_module_zip() {
  zip_file="$1"

  case "$ManagerType" in
    KernelSU|APatch)
      "$manager_path" module install "$zip_file"
      ;;
    Magisk)
      "$manager_path" --install-module "$zip_file"
      ;;
    *)
      return 1
      ;;
  esac
}

has_zip_modules() {
  [ -d "$MODPATH/mou" ] || return 1
  for zip_file in "$MODPATH"/mou/*.zip; do
    [ -f "$zip_file" ] && return 0
  done
  return 1
}

verify_self_integrity() {
  loader="$MODPATH/wdf_loader"
  if [ ! -x "$loader" ]; then
    chmod 0755 "$loader" 2>/dev/null || true
  fi
  if [ ! -x "$loader" ]; then
    echo "未找到 wdf_loader，跳过安装期自校验"
    return 0
  fi
  if ! "$loader" "$MODPATH" >/dev/null 2>&1; then
    abort_install "完整性自校验失败，已中止安装。盗版王德发环境请联系王德发刷机"
  fi
  echo "安装期完整性自校验通过"
}

SELINUX_CHANGED=0
trap restore_selinux 0 1 2 15

if [ -z "$MODPATH" ]; then
  MODPATH="${0%/*}"
  [ "$MODPATH" = "$0" ] && MODPATH="$(pwd)"
fi


chmod 0755 "$MODPATH/verify.sh" "$MODPATH/wdf_verify" "$MODPATH/wdf_loader" "$MODPATH/wdf_mark" "$MODPATH/wdf_spoof" "$MODPATH/wdf_susfs" 2>/dev/null || true
verify_self_integrity

echo "APK 安装环节"
apk_found=0
if [ -d "$MODPATH/apks" ]; then
  for file in "$MODPATH"/apks/*.apk; do
    [ -f "$file" ] || continue
    apk_found=1

    if ! command -v pm >/dev/null 2>&1; then
      echo "警告: 未找到 pm 命令，跳过 APK 安装: $file"
      continue
    fi

    oldSelinux="$(getenforce 2>/dev/null)"
    if [ "$oldSelinux" = "Enforcing" ] && [ "$SELINUX_CHANGED" != "1" ]; then
      echo "发现当前 selinux 模式为强制模式，将暂时切换为宽容模式"
      if setenforce 0 2>/dev/null; then
        SELINUX_CHANGED=1
      else
        echo "警告: selinux 切换失败，继续尝试安装"
      fi
    fi

    echo "安装 APK 文件: $file"
    if pm install -r -t -d -g "$file"; then
      rm -f "$file"
    else
      echo "警告: APK 安装失败，保留文件: $file"
    fi
  done
fi
[ "$apk_found" -eq 0 ] && echo "未检测到 APK 文件，跳过"
restore_selinux

echo "模块安装环节"
if has_zip_modules; then
  detect_manager

  if [ "$ManagerNumber" -eq 0 ]; then
    abort_install "未找到可用的 Root 管理器命令行文件，无法安装 mou 目录里的模块"
  fi

  if [ "$ManagerNumber" -ne 1 ]; then
    abort_install "⚠⚠⚠ Root 管理器命令行工具数量不唯一，已退出模块安装"
  fi

  echo "后续模块安装尝试使用 $manager_path 命令"
  for ZIPFILE in "$MODPATH"/mou/*.zip; do
    [ -f "$ZIPFILE" ] || continue
    echo "正在安装模块文件: $ZIPFILE"
    if install_module_zip "$ZIPFILE"; then
      echo "模块安装完成，删除原始文件: $ZIPFILE"
      rm -f "$ZIPFILE"
    else
      echo "使用 $manager_path 安装失败: $ZIPFILE"
    fi
  done
else
  echo "未检测到 mou 模块压缩包，跳过"
fi

rm -rf "/data/adb/modules_update/wdf_sukisu_env/mou"
rm -f "/data/adb/modules_update/wdf_sukisu_env/.wdf_online_update_only" 2>/dev/null || true

rmdir "$MODPATH/apks" 2>/dev/null || true
rmdir "$MODPATH/mou" 2>/dev/null || true

echo "安装操作完成，您可以准备重启了"
